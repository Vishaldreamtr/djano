from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return HttpResponse('Hello worlds')

def login(request):
    return render(request, 'index.html')

def auth(request):
    return render(request, 'index.html')