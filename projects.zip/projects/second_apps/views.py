from django.shortcuts import render, HttpResponse

# Create your views here.

def auth(request):
    return HttpResponse('Hello universe')

def kuch(request):
    return render (request, 'apps/index.html')