from django.contrib import auth
from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout, authenticate


# # Create your views here.  
def signup(request):
    if request.method == 'GET':
        return render (request, 'app/index.html')
    
    
    elif request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        user = User.objects.create_user(username, email, password)
        auth_login(request, user)
      
        return HttpResponse("Succefully stored to the database and logged in -----<br/>For logout <a href='/signup'>Click here<a/>")


def auth(request):
    return render(request, 'app/temp.html')
# def signup(request):
#     if request.method =='GET':
#         return render (request, 'app/index.html')
#     if request.method == 'POST':

#         username = request.POST['username']
#         email = request.POST['email']
#         password = request.POST['password']                    

#         user = User.objects.create_user(username, email, password)
#         login(request, user)
#         return HttpResponse("Succefully stored to the database and logged in")

       

def logoutbtn(request):
    logout(request)
    return HttpResponse('For logout <a href="/signup">Click here<a/>') 
