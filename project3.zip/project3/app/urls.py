
from django.urls import path
from app import views

urlpatterns = [
    
    path('signup/', views.signup, name="signup" ),
    path('logout/', views.logoutbtn, name="logout"), 
    path('auth/', views.auth, name="auth")
]