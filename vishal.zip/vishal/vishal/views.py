from django.http import HttpRequest
from django.http.response import HttpResponse

def index(request):
    return HttpResponse('Hello world')
