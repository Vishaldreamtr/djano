from django.contrib import auth
from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout , authenticate
def signup(request):
    if request.method == "GET":
        return render(request, 'first_apps/index.html')
    elif request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']

        user = User.objects.create_user(username, email, password)
        auth_login(request, user)
        return HttpResponse("Succefully stored to the database and logged in")

        # dict = {
        #     'username':username,
        #     'email':email,
        #     'password':password
        # }
        # return render(request, 'first_apps/temp.html', dict)



def login(request):
    if request.user.is_authenticated:
        return HttpResponse("You are logged in for logout <a href='/logout'>click here</a>")
    else:
        return HttpResponse("You are not logged in")

def logoutbtn(request):
    logout(request)
    return redirect('login')