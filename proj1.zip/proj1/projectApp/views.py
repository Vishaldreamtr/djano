from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return HttpResponse ("Hello world")

def portal(request):
    return HttpResponse ("Yo Ho gaya ")

