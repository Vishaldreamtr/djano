from django.urls import path
from . import views

urlpatterns = [
    path('', views.simple,name="simple"),
    path('vishal/', views.vishal, name="vishal"),
    path('vis/', views.viw, name="vis"),
    path('logout/', views.logoutbtn, name="logout"),
    path('login/', views.login, name="login"),
    path('status/', views.status, name="status")
    
]
