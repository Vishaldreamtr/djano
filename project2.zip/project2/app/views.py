from django.shortcuts import render,  HttpResponse, redirect
from django.contrib.auth import login as auth_login
from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate

# Create your views here.
def vishal(request):
     return HttpResponse("hello world")

def viw(request):
    if request.method =='GET':
        return render(request, 'app/index.html')
    elif request.method =='POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']                    

        user = User.objects.create_user(username, email, password)
        auth_login(request, user)
        return HttpResponse("Succefully stored to the database and logged in")

def logoutbtn(request):
    logout(request)
    return redirect('login')

def login(request):
    if request.user.is_authenticated:
        return redirect('status')
    if request.method == "GET":
        return render(request, 'app/login.html')
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('status')
        else:
            return HttpResponse("invalid credentials <a href='/login'>login</a>")

def status(request):
    if request.user.is_authenticated:
        return HttpResponse("You are logged in <a href='/logout'>logout</a>")
    else:
        return HttpResponse("You are not logged in <a href='/login'>login here</a>")

def simple(request):
    return render(request, 'app/simple.html')